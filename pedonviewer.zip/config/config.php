<?php

// db config

$config['db']['host']=APP_PATH.'core/db/npdb.sqlite';
//$config['db']['username']='admin';
//$config['db']['password']='123456';
//$config['db']['dbname']='project';

//default controller and default action
$config['defaultController']='Home';
$config['defaultAction']='index';

return $config;