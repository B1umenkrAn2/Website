<div class="container">
    <div class="row card">
        <div class="col-4 card" id="1">
            <P>here is text</P>
        </div>
        <div class="col-8 card" id="2">
            <p>here is a pic</p>
        </div>
    </div>
    <div class="align-self-end card">
        <p><a href="next">next</p>
    </div>
</div>