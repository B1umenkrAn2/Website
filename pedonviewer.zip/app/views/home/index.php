


    <!-- Main content -->
    <section class="container my-3">
        <div class=" row">
                <div class="col-xl-4  col-lg-4">
                    <div class="small-box ">
                        <h3>Database</h3>
                        <p>View all padon data on our website.</p>
                        <a class="btn btn-primary" href="info/selector">More info </a>
                    </div>
                </div>

                <div class="col-xl-4   col-lg-4">
                    <div class="small-box ">
                        <h3>Description</h3>
                        <p>Database Attribute descriptions </p>
                        <a class="btn btn-primary" href="Description" >More info </a>
                    </div>
                </div>

<!--                <div class=" col-xl-3 col-lg-3">-->
<!--                    <div class="small-box ">-->
<!--                        <h3>Download</h3>-->
<!--                        <p>Download selected data from our website</p>-->
<!--                        <a class="btn btn-primary" href="download/selector" >More info </a>-->
<!--                    </div>-->
<!--                </div>-->

                <div class=" col-xl-4 col-lg-4">
                    <div class="small-box ">
                        <h3>Management</h3>
                        <p>Admin login</p>
                        <a class="btn btn-primary" href="Management/login" >More info</a>
                    </div>
                </div>
        </div>
    </section>


